-- MariaDB dump 10.17  Distrib 10.5.6-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: octoquest
-- ------------------------------------------------------
-- Server version	10.5.6-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `disciplina`
--

DROP TABLE IF EXISTS `disciplina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disciplina` (
  `cod_disciplina` int(11) NOT NULL AUTO_INCREMENT,
  `nome_disciplina` varchar(50) DEFAULT NULL,
  `sigla_disciplina` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`cod_disciplina`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disciplina`
--

LOCK TABLES `disciplina` WRITE;
/*!40000 ALTER TABLE `disciplina` DISABLE KEYS */;
INSERT INTO `disciplina` VALUES (1,'Matemática','MAT'),(2,'Português','PT'),(3,'Química','QUI'),(4,'Física','FIS'),(5,'Biologia','BIO'),(6,'Geografia','GEO'),(7,'História','HIST'),(8,'Sociologia','SOC'),(9,'Filosofia','FILO'),(10,'Espanhol','ESP'),(11,'Inglês','ING'),(12,'Redação','RED');
/*!40000 ALTER TABLE `disciplina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prova`
--

DROP TABLE IF EXISTS `prova`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prova` (
  `cod_prova` int(11) NOT NULL AUTO_INCREMENT,
  `titulo_prova` varchar(200) DEFAULT NULL,
  `salva` tinyint(1) DEFAULT NULL,
  `cadastro` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_prova`),
  KEY `´fk_usuario´` (`cadastro`),
  CONSTRAINT `´fk_usuario´` FOREIGN KEY (`cadastro`) REFERENCES `usuario` (`cadastro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prova`
--

LOCK TABLES `prova` WRITE;
/*!40000 ALTER TABLE `prova` DISABLE KEYS */;
/*!40000 ALTER TABLE `prova` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prova_questao`
--

DROP TABLE IF EXISTS `prova_questao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prova_questao` (
  `cod_questao` int(11) DEFAULT NULL,
  `cod_prova` int(11) DEFAULT NULL,
  KEY `´fk_questao1´` (`cod_questao`),
  KEY `´fk_prova´` (`cod_prova`),
  CONSTRAINT `´fk_prova´` FOREIGN KEY (`cod_prova`) REFERENCES `prova` (`cod_prova`),
  CONSTRAINT `´fk_questao1´` FOREIGN KEY (`cod_questao`) REFERENCES `questao` (`cod_questao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prova_questao`
--

LOCK TABLES `prova_questao` WRITE;
/*!40000 ALTER TABLE `prova_questao` DISABLE KEYS */;
/*!40000 ALTER TABLE `prova_questao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questao`
--

DROP TABLE IF EXISTS `questao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questao` (
  `cod_questao` int(11) NOT NULL AUTO_INCREMENT,
  `titulo_questao` varchar(50) DEFAULT NULL,
  `descricao` varchar(20000) DEFAULT NULL,
  `tipo_questao` varchar(50) DEFAULT NULL,
  `aprovado` tinyint(1) DEFAULT NULL,
  `cod_tema` int(11) DEFAULT NULL,
  `cadastro` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_questao`),
  KEY `´fk_tema´` (`cod_tema`),
  KEY `´fk_usuario1´` (`cadastro`),
  CONSTRAINT `´fk_tema´` FOREIGN KEY (`cod_tema`) REFERENCES `tema` (`cod_tema`),
  CONSTRAINT `´fk_usuario1´` FOREIGN KEY (`cadastro`) REFERENCES `usuario` (`cadastro`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questao`
--

LOCK TABLES `questao` WRITE;
/*!40000 ALTER TABLE `questao` DISABLE KEYS */;
INSERT INTO `questao` VALUES (1,'Citologia','UERJ 2019/1 - Macromoléculas polares são capazes de atravessar a membrana plasmática celular, passando do meio externo para o meio interno da célula. Essa passagem é possibilitada pela presença do seguinte componente na membrana plasmática:','Dissertativa',2,22,NULL),(2,'Saúde','Durante as estações chuvosas, aumentam no Brasil as campanhas de prevenção à dengue, que têm como objetivo a redução da proliferação do mosquito Aedes aegypti, transmissor do vírus da dengue. Que proposta preventiva poderia ser efetivada para diminuir a reprodução desse mosquito?','Dissertativa',2,23,NULL),(3,'Genética','Com base nos experimentos de plantas de Mendel, foram estabelecidos três princípios básicos, que são conhecidos como leis da uniformidade, segregação e distribuição independente. A lei da distribuição independente refere-se ao fato de que os membros de pares diferentes de genes segregam-se independentemente, uns dos outros, para a prole. Hoje, sabe-se que isso nem sempre é verdade. Por quê?','Dissertativa',2,24,NULL),(4,'Evolução','A principal explicação para a grande variedade de espécies na Amazônia é a teoria do refúgio. Nos últimos 100 000 anos, o planeta sofreu vários períodos de glaciação, em que as florestas enfrentaram fases de seca. Dessa forma, as matas expandiram-se e depois reduziram-se. Nos períodos de seca prolongados, cada núcleo de floresta ficava isolado do outro. Então, os grupos de animais dessas áreas isoladas passaram por processos de diferenciação genética, muitas vezes se transformando em espécies ou subespécies diferentes das originais e das que ficaram em outros refúgios. O principal processo evolutivo relacionado ao texto é a: ','Dissertativa',2,25,NULL),(5,'Sistema Nervoso','(Cesgranrio-RJ) Os anestésicos, largamente usados pela Medicina, tornam regiões ou todo o organismo insensível à dor porque atuam:','Dissertativa',2,26,NULL),(6,'Sistema Imunológico','(Enem – 2014) - Embora sejam produzidos e utilizados em situações distintas, os imunobiológicos I e II atuam de forma semelhante nos humanos e equinos, pois:','Dissertativa',2,27,NULL),(7,'A Pré-História','(Enem) Os nossos ancestrais dedicavam-se à caça, à pesca e à coleta de frutas e vegetais, garantindo sua subsistência, porque ainda não conheciam as práticas de agricultura e pecuária. Uma vez esgotados os alimentos, viam-se obrigados a transferir o acampamento para outro lugar.O texto refere-se ao movimento migratório denominado','Dissertativa',2,34,NULL),(8,'Religião Egípcia','(Vunesp) Os Estados teocráticos da Mesopotâmia e do Egito evoluíram acumulando características comuns e peculiaridades culturais. Os egípcios desenvolveram a prática de embalsamar o corpo humano porque?','Dissertativa',2,35,NULL),(9,'A Fenícia','Os fenícios, que desenvolveram sua civilização na região onde hoje se encontra o Estado do Líbano, destacaram-se como grandes comerciantes marítimos. Entretanto, outro importante legado foi deixado pelos fenícios para as civilizações posteriores. Qual foi este legado?','Dissertativa',2,36,NULL),(10,'Grécia Antiga','Na Grécia Antiga, as principais cidades-estado foram?','Dissertativa',2,37,NULL),(11,NULL,'$descricao',NULL,NULL,NULL,NULL),(12,NULL,'$descricao',NULL,NULL,NULL,NULL),(13,NULL,'$descricao',NULL,NULL,NULL,NULL),(14,NULL,'um dia joguei bola',NULL,NULL,NULL,NULL),(15,NULL,'teste','Disssertativa',NULL,NULL,NULL),(16,NULL,'teste1','Disssertativa',NULL,NULL,3),(17,NULL,'Qual o dia d','Disssertativa',NULL,NULL,3),(18,NULL,'isuaiuiuks','Disssertativa',NULL,NULL,3),(19,NULL,'','Disssertativa',NULL,NULL,3),(20,NULL,'isaiusisu','Disssertativa',NULL,NULL,3),(21,NULL,'adsad','Disssertativa',NULL,NULL,3),(22,NULL,'ijuaiosoaij','Disssertativa',NULL,NULL,3),(23,NULL,'isuaiosoiusoi','Disssertativa',NULL,NULL,3),(24,NULL,'aaaaaaaaaaaaa','Disssertativa',NULL,NULL,3),(25,NULL,'teste teste teste','Disssertativa',NULL,NULL,3),(26,NULL,'vai Corinthians ','Disssertativa',NULL,NULL,3),(27,NULL,'aula bdd','Disssertativa',NULL,NULL,14),(28,NULL,'jsnoisjaoijsioljkmas','Disssertativa',NULL,NULL,14),(29,NULL,'','Disssertativa',NULL,NULL,14),(30,NULL,'ijsoiasjaoijsioaj','Disssertativa',NULL,NULL,14),(31,NULL,'kajskjJ','Disssertativa',NULL,NULL,14),(32,NULL,'','Disssertativa',NULL,NULL,14),(33,NULL,'pppppppppppp','Disssertativa',NULL,NULL,14),(34,NULL,'isuakiushukas','Disssertativa',NULL,NULL,16),(35,NULL,'','Disssertativa',NULL,NULL,16),(36,NULL,'sajkhsdauihsdisuah','Disssertativa',NULL,NULL,16),(37,NULL,'sasoiuaous','Disssertativa',NULL,NULL,16),(38,NULL,'aaaaaaaaaaaaaaaa','Disssertativa',NULL,NULL,17);
/*!40000 ALTER TABLE `questao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resposta`
--

DROP TABLE IF EXISTS `resposta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resposta` (
  `cod_resposta` int(11) NOT NULL AUTO_INCREMENT,
  `correto` varchar(1000) DEFAULT NULL,
  `cod_questao` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_resposta`),
  KEY `´fk_questao´` (`cod_questao`),
  CONSTRAINT `´fk_questao´` FOREIGN KEY (`cod_questao`) REFERENCES `questao` (`cod_questao`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resposta`
--

LOCK TABLES `resposta` WRITE;
/*!40000 ALTER TABLE `resposta` DISABLE KEYS */;
INSERT INTO `resposta` VALUES (1,'Proteína',1),(2,'Remoção dos recipientes que possam acumular água, porque as larvas do mosquito se desenvolvem nesse meio.',2),(3,'Os genes localizados fisicamente próximos no mesmo cromossomo tendem a ser herdados juntos.',3),(4,'Evolução alopátrica',4),(5,'Nas sinapses, impedindo a transmissão do impulso nervoso.',5),(6,'Estimulam a produção de anticorpos.',6),(7,'Nomadismo',7),(8,'depois da morte a alma podia voltar ao corpo mumificado.',8),(9,'Criação de uma escrita e um alfabeto fonético.',9),(10,'Atenas e Esparta',10),(11,'sssss',31),(12,'a',32),(13,'b',32),(14,'c',32),(15,'d',32),(16,'e',32),(17,'das',33),(18,'dad',33),(19,'das',33),(20,'fras',33),(21,'daff',33),(22,'ljsuaiusyiauyhsd',36),(23,'asuajiosuioa',37),(24,'aihsuiahsmo',37),(25,'hashasiojs',37),(26,'suoaiujso',37),(27,'uiahsihna',37),(28,'aaaaaaaaaaaaaa',38);
/*!40000 ALTER TABLE `resposta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tema`
--

DROP TABLE IF EXISTS `tema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tema` (
  `cod_tema` int(11) NOT NULL AUTO_INCREMENT,
  `nome_tema` varchar(50) DEFAULT NULL,
  `sigla_tema` varchar(5) DEFAULT NULL,
  `cod_disciplina` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_tema`),
  KEY `´fk_disciplina´` (`cod_disciplina`),
  CONSTRAINT `´fk_disciplina´` FOREIGN KEY (`cod_disciplina`) REFERENCES `disciplina` (`cod_disciplina`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tema`
--

LOCK TABLES `tema` WRITE;
/*!40000 ALTER TABLE `tema` DISABLE KEYS */;
INSERT INTO `tema` VALUES (1,'Conjuntos Numéricos','CJN',NULL),(2,'Função','FÇ',NULL),(3,'Função de 1 grau','FÇ1',NULL),(4,'Funçaõ de 2 grau','FÇ2',NULL),(5,'Teoria de Conjuntos','CJN',NULL),(6,'Textos verbais e não-verbais','TVTN',NULL),(7,'Texto x Contexto','TC',NULL),(8,'Período simples','PS',NULL),(9,'Pontuação','PONT',NULL),(10,'Figuras de sintaxe','FL',NULL),(11,'Funções Químicas','FQ',NULL),(12,'Modelos atômicos','MA',NULL),(13,'Tabela periódica','TP',NULL),(14,'Transformações químicas','TQ',NULL),(15,'Propriedades dos materiais','PM',NULL),(16,'Grandezas escalares e vetoriais;','GEV',NULL),(17,'Movimentos retilíneos','MR',NULL),(18,'lançamentos de projéteis','LP',NULL),(19,'Força peso','FP',NULL),(20,' força de atrito','FA',NULL),(21,'e força resultante','FR',NULL),(22,'Citologia','CITO',NULL),(23,'Saúde','SAU',NULL),(24,'Genética','GEN',NULL),(25,'Evolução','EVO',NULL),(26,'Sistema Nervoso','SN',NULL),(27,'Sistema Imunitário','SI',NULL),(28,'Democracia','DEM',NULL),(29,'Meritocracia','MER',NULL),(30,'Classe social','CS',NULL),(31,'Religião','RLG',NULL),(32,'Comunismo','COM',NULL),(33,'A Pré-História','PH',NULL),(34,' Antigo Egito','AE',NULL),(35,'Religião Egípcia','RE',NULL),(36,'A Fenícia','F',NULL),(37,'Grécia Antiga','GA',NULL),(38,'Meio Ambiente','MA',NULL),(39,'Poluição','POLU',NULL),(40,'Indústria','IND',NULL),(41,'Agricultura','AGRC',NULL),(42,'A questão democrática','QD',NULL),(43,'Arte e Técnica','AT',NULL),(44,'Bioética','BT',NULL),(45,'Corpo Humano','CH',NULL),(46,'Numbers','NUM',NULL),(47,'Colors','COL',NULL),(48,'Horas','HO',NULL),(49,'Dias da semana','DS',NULL),(50,'Números','N',NULL),(51,'Muy e mucho','MM',NULL),(52,'Mobilidade urbana sustentáve','MUS',NULL),(53,'O combate às epidemias no Brasil','CEB',NULL),(54,'Obesidade no Brasil','OB',NULL),(55,'Aumento das DSTs entre jovens brasileiros','ADJB',NULL),(56,'A evasão escolar em questão no Brasil','EEQB',NULL),(57,'O combate à depressão na sociedade brasileira','CDSB',NULL),(58,'Democratização do acesso ao cinema no Brasil','DACB',NULL),(59,'O perigo da escassez da água no Brasil','PEAB',NULL),(60,'Caminhos para combater os maus-tratos aos animais','CCMTA',NULL);
/*!40000 ALTER TABLE `tema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `cadastro` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `nome_usuario` varchar(15) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `instituicao` text DEFAULT NULL,
  `tipo_insti` text DEFAULT NULL,
  PRIMARY KEY (`cadastro`),
  UNIQUE KEY `Index 2` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'joana','joana@joana.joana','joana','123645','1236554','joana','joana'),(2,'fabiola','joana@fabiola','fabiola','123645','123','IFSP','Ensino Médio'),(3,'alice','alice@alice','alice','123458','0cc175b9c0f1b6a831c399e269772661','IFSP','Ensino Médio'),(4,'thiago','thiago@thiago','thiago','1545','e358efa489f58062f10dd7316b65649e','IFSP','Ensino Médio'),(5,'felipe','felipe@felipe','felipe','1458','8fa14cdd754f91cc6554c9e71929cce7','IFSP','Ensino Médio'),(6,'henrique','henrique@henrique','henrique','45787','2510c39011c5be704182423e3a695e91','IFSP','Ensino Médio'),(7,'guilherme','guilherme@guilherme','guilherme','45788','b2f5ff47436671b6e533d8dc3614845d','IFSP','Ensino Médio'),(8,'claudia ','claudia@aptacontabilidade.com.br','clau','5758656','4a8a08f09d37b73795649038408b5f33','IFSP','Ensino Médio'),(9,'rodrigo','rodrigo.furman@rodrigo','rodrigo','8445454','4b43b0aee35624cd95b910189b3dc231','IFSP','Ensino Médio'),(11,'Matheus','mathues@matheus','matheus','7899785','6f8f57715090da2632453988d9a1501b','IFSP','Ensino Médio'),(12,'ana','ana@ana','ana','7855555','0cc175b9c0f1b6a831c399e269772661','IFSP','Ensino Médio'),(14,'julio','julio@julio','julio','(54) 5415-1521','363b122c528f54df4a0446b6bab05515','IFSP','Ensino Médio'),(15,'','','','','d41d8cd98f00b204e9800998ecf8427e','',''),(16,'he','he@he','he','(85) 4522-2022','6f96cfdfe5ccc627cadf24b41725caa4','IFSP','Ensino Médio'),(17,'clara','clara@clara','clara','(51) 3210-3210','161747ec4dc9f55f1760195593742232','IFSP','Ensino Médio');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-26 14:55:16
